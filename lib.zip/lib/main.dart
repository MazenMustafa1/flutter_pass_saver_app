import 'dart:io';

import 'package:flutter/material.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'screens/home-screen.dart';

ColorScheme kColorScheme = const ColorScheme.light(
    primary: Color.fromARGB(255, 6, 19, 190), secondary: Colors.green);

ColorScheme kDarkColorScheme = ColorScheme.fromSeed(
  seedColor: const Color.fromARGB(255, 56, 9, 12),
  brightness: Brightness.dark,
);

void main() async {
  //for desktop
  if (Platform.isWindows) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      darkTheme: ThemeData(
        colorScheme: kDarkColorScheme,
        useMaterial3: true,
        appBarTheme: AppBarTheme(
          backgroundColor: kDarkColorScheme.inversePrimary,
        ),
        cardTheme: const CardTheme(
            color: Color.fromARGB(255, 116, 72, 68), elevation: 7),
        textTheme: const TextTheme(
            // titleLarge: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            headlineMedium: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
        )),
      ),
      theme: ThemeData(
        colorScheme: kColorScheme,
        useMaterial3: true,
        appBarTheme: AppBarTheme(
            backgroundColor: kColorScheme.primary,
            titleTextStyle: const TextStyle(color: Colors.white, fontSize: 25)),
        textTheme: const TextTheme(
            headlineMedium:
                TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        cardTheme: const CardTheme(elevation: 7, shadowColor: Colors.black),
      ),
      home: const MyHomePage(title: 'Password Saver'),
      // themeMode: ThemeMode.dark,
      debugShowCheckedModeBanner: false,
    );
  }
}
