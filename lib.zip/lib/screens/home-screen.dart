import 'dart:async';

import 'package:flutter/material.dart';

import '../data.dart';
import '../helpers/db-helper.dart';
import '../my-form.dart';
import '../list-item.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  dynamic _data;

  @override
  void initState() {
    _data = fetchAndSetData();
    // TODO: implement initState
    super.initState();
  }

  void addItem(email, password) async {
    int id =
        await DbHelper.addToDb('Users', {"email": email, "password": password});

    setState(() {
      list.add({"id": id, "email": email, "password": password});
    });
  }

  Future<void> fetchAndSetData() async {
    await Future.delayed(Duration(seconds: 4));
    final listOfEntries = await DbHelper.getData('Users');

    print(listOfEntries);
    list = [...listOfEntries];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: FutureBuilder(
        future: _data,
        builder: (ctx, snapshot) {
          if (snapshot.hasError) {
            return const Center(
              child: Text('Error Fetching data'),
            );
          }

          return snapshot.connectionState == ConnectionState.waiting
              ? Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const CircularProgressIndicator(),
                    const SizedBox(
                      height: 20,
                    ),
                    Text(
                      'Loading Passwords...',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.displayMedium,
                    )
                  ],
                )
              : list.isEmpty
                  ? const Center(
                      child: Text(
                        "There are no passwords now, start adding some!",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 25, fontWeight: FontWeight.bold),
                      ),
                    )
                  : ListView.builder(
                      itemBuilder: (context, index) => Dismissible(
                        onDismissed: (_) {
                          DbHelper.deleteFromDb('Users', list[index]['id']);
                          setState(() {
                            list.removeAt(index);
                          });
                        },
                        direction: DismissDirection.endToStart,
                        background: Container(
                          alignment: Alignment.centerRight,
                          color: Colors.red,
                          child: const Icon(Icons.delete),
                        ),
                        key: UniqueKey(),
                        child: ListItem(
                          index: index,
                        ),
                      ),
                      itemCount: list.length,
                    );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showModalBottomSheet(
            isScrollControlled: true,
            context: context,
            builder: (context) => SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom,
                ),
                child: MyForm(addItem),
              ),
            ),
          );
        },
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ),
    );
  }
}
