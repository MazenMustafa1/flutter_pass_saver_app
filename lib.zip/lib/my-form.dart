import 'package:flutter/material.dart';

class MyForm extends StatefulWidget {
  MyForm(this.addItem);
  final addItem;

  @override
  State<MyForm> createState() => _MyFormState();
}

class _MyFormState extends State<MyForm> {
  final TextEditingController? emailController = TextEditingController();

  final TextEditingController? passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 50),
          child: TextField(
            controller: emailController,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
                border: OutlineInputBorder(), labelText: 'Email'),
          ),
        ),
        Container(
          margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 50),
          child: TextField(
            controller: passwordController,
            keyboardType: TextInputType.visiblePassword,
            decoration: const InputDecoration(
                iconColor: Colors.pink,
                border: OutlineInputBorder(),
                labelText: 'password'),
          ),
        ),
        Container(
          padding: const EdgeInsets.only(top: 40),
          alignment: Alignment.bottomRight,
          child: TextButton(
              onPressed: () {
                widget.addItem(emailController?.text, passwordController?.text);
                Navigator.of(context).pop();
              },
              child: const Text("Submit")),
        )
      ],
    );
  }
}
