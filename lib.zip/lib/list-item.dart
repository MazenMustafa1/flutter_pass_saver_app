import 'package:flutter/material.dart';

import 'data.dart';

class ListItem extends StatelessWidget {
  const ListItem({super.key, this.index});

  final index;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 5),
      width: double.infinity,
      child: Card(
        child: Column(children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.email),
              Flexible(
                child: Text(
                  'Email: ${list[index]["email"]}',
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 20,
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.no_encryption),
              Flexible(
                child: Text('Password: ${list[index]["password"]}',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.bold)),
              ),
            ],
          )
        ]),
      ),
    );
  }
}
