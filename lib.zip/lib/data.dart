List<dynamic> list = [];

/*
list was [
  {'email': '....', 'password': '.....'}
]
*/
